namespace Facade.Entities
{
    public class WeatherFacadeResults
    {
        public int Fahrenheit { get; set; }
        public int Celsius { get; set; }
        public City City { get; set; }
        public State State { get; set; }
    }
}