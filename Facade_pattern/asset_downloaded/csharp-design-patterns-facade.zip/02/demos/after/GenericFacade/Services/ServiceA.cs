namespace GenericFacade.Services
{
    public class ServiceA
    {
        public void Method1()
        {
            // do some work
        }

        public int Method2()
        {
            // do some work
            return 0;

        }
    }
}