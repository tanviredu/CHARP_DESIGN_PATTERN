namespace GenericFacade.Services
{
    public class ServiceC
    {
        public double Method1()
        {
            // do some work

            return 1.01;
        }

        public string Method2()
        {
            // do some work

            return "ServiceC string";
        }
    }
}