# C# Design Patterns: Decorator
This repository contains the course code to accompany the Pluralsight course _C# Design Patterns: Decorator_
